# SafeZone AI — Software Prototype

CPU-compatible webcam restricted-zone monitoring using OpenCV's built-in HOG pedestrian detector.

## Run (Windows)
```powershell
py -m pip install -r requirements.txt
py main.py
```
Press Q to exit. Events are written to `incidents.json` when a detected person's bottom-center point is inside the central red zone (at most once every 10 seconds).

## Limitations
- **Not a qualifying PipeGen hackathon submission:** does not use PipeGen, NVIDIA TensorRT, or DeepStream.
- OpenCV HOG detection can miss people, especially at close range or with only a partial body visible. Best tested with a full-body person several feet from the camera in good lighting.
- The restricted zone is hard-coded in `main.py` and can be adjusted.
- JSON file is created only when a qualifying intrusion is detected.
