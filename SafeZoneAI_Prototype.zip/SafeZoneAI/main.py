import cv2
import json
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOG = ROOT / 'incidents.json'

# OpenCV's built-in HOG pedestrian detector: CPU-compatible, no model download.
hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
if not cap.isOpened():
    cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise SystemExit('Camera unavailable. Check Windows camera permissions and close other camera apps.')

incidents = []
if LOG.exists():
    try:
        data = json.loads(LOG.read_text(encoding='utf-8'))
        if isinstance(data, list):
            incidents = data
    except (json.JSONDecodeError, OSError):
        pass

last_logged = 0.0
frame_num = 0
boxes = []
print('SafeZone AI started. Press Q in the video window to quit.')

while True:
    ok, frame = cap.read()
    if not ok:
        print('Unable to read camera frame.')
        break
    frame = cv2.resize(frame, (640, 480))
    h, w = frame.shape[:2]
    # Central zone, adjustable via these fractional coordinates.
    x1, y1, x2, y2 = int(w * .32), int(h * .18), int(w * .78), int(h * .88)
    frame_num += 1
    if frame_num % 6 == 1:
        found, weights = hog.detectMultiScale(frame, winStride=(8, 8), padding=(8, 8), scale=1.05)
        boxes = [(int(x), int(y), int(bw), int(bh), float(score))
                 for (x, y, bw, bh), score in zip(found, weights)]

    intrusion = False
    for x, y, bw, bh, confidence in boxes:
        foot_x, foot_y = x + bw // 2, y + bh
        inside = x1 <= foot_x <= x2 and y1 <= foot_y <= y2
        intrusion = intrusion or inside
        color = (0, 0, 255) if inside else (0, 255, 0)
        cv2.rectangle(frame, (x, y), (x + bw, y + bh), color, 2)
        cv2.putText(frame, 'PERSON', (x, max(20, y - 8)), cv2.FONT_HERSHEY_SIMPLEX, .6, color, 2)

    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)
    cv2.putText(frame, 'RESTRICTED ZONE', (x1, max(25, y1 - 10)),
                cv2.FONT_HERSHEY_SIMPLEX, .6, (0, 0, 255), 2)
    status = 'INTRUSION ALERT!' if intrusion else 'Monitoring - no intrusion'
    cv2.putText(frame, status, (15, 35), cv2.FONT_HERSHEY_SIMPLEX,
                .8, (0, 0, 255) if intrusion else (0, 200, 0), 2)

    now = datetime.now()
    if intrusion and now.timestamp() - last_logged >= 10:
        incident = {'timestamp': now.isoformat(timespec='seconds'),
                    'event': 'restricted_zone_intrusion', 'source': 'webcam'}
        incidents.append(incident)
        LOG.write_text(json.dumps(incidents, indent=2), encoding='utf-8')
        print('ALERT:', incident)
        last_logged = now.timestamp()

    cv2.imshow('SafeZone AI - Press Q to quit', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
